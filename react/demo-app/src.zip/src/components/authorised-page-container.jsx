import React from "react";
import Roles from "./Roles";


const AuthorisedPageContainer = () => ( 
    <Roles />
);

export default AuthorisedPageContainer;
